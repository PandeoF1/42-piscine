 
                        /(((((((/    ,((((((((((((,                
                     .(&&&&&&&&&(    /&&&&&&&&&&&&&              
                    (&&&&&&&&&&&(    /&&&&&&&&&&&&&&&&*            
                 .(&&&&&&&&&&&&&(    *&&&&&&%#####&&&&&&*          
                /%%%%%%%&&&&&&&&(     .%&&&&&,    #&&&&          
                        #&&&&&&&(       .%&&&&&(  #&&&&          
                        #&&&&&&&(          #&&&&&(#&&&&          
                        #&&&&&&&(                 #&&&&          
                        #&&&&&&&(                 #&&&&          
                        #&&&&&&&(                 #&&&&          
                        #&&&&&&&(     %&&&&&&&&&&&&&&&&          
                        #&&&&&&&(      *&&&&&&&&&&&&&&&          
                        #&&&&&&&(        *&&&&&&&&&&&&&          
                        #&&&&&&&(          .////////////*          
                        #&&&&&&&(                                  
                        #&&&&&&&(                                  
                        #&&&&&&&(                                  


          BBBBBBBBBBBBBBBBB      SSSSSSSSSSSSSSS      QQQQQQQQQ      
          B::::::::::::::::B   SS:::::::::::::::S   QQ:::::::::QQ    
          B::::::BBBBBB:::::B S:::::SSSSSS::::::S QQ:::::::::::::QQ  
          BB:::::B     B:::::BS:::::S     SSSSSSSQ:::::::QQQ:::::::Q 
            B::::B     B:::::BS:::::S            Q::::::O   Q::::::Q 
            B::::B     B:::::BS:::::S            Q:::::O     Q:::::Q 
            B::::BBBBBB:::::B  S::::SSSS         Q:::::O     Q:::::Q 
            B:::::::::::::BB    SS::::::SSSSS    Q:::::O     Q:::::Q 
            B::::BBBBBB:::::B     SSS::::::::SS  Q:::::O     Q:::::Q 
            B::::B     B:::::B       SSSSSS::::S Q:::::O     Q:::::Q 
            B::::B     B:::::B            S:::::SQ:::::O  QQQQ:::::Q 
            B::::B     B:::::B            S:::::SQ::::::O Q::::::::Q 
          BB:::::BBBBBB::::::BSSSSSSS     S:::::SQ:::::::QQ::::::::Q 
          B:::::::::::::::::B S::::::SSSSSS:::::S QQ::::::::::::::Q  
          B::::::::::::::::B  S:::::::::::::::SS    QQ:::::::::::Q   
          BBBBBBBBBBBBBBBBB    SSSSSSSSSSSSSSS        QQQQQQQQ::::QQ 
                                                              Q:::::Q
                                                               QQQQQQ

         ==============================================================

      Here are some tests for the BSQ project of school 42 and 19 C pools.
    
    In order to run them, clone this repo into a folder INTO your BSQ project's
      directory (e.g. bsq/test), and launch the "test_my_bsq_please.sh" script 
        via the command "zsh test_my_bsq_please.sh", or as an executable
    
